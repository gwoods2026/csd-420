// Garret Woods Module 1.3

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class main extends Application {

    //array for the deck
    private final List<Integer> deck = new ArrayList<>();

    //creates a box to display the cards
    private final HBox cardPane = new HBox(15);

    @Override
    public void start(Stage primaryStage){

        //creates the deck
        for(int i = 1; i<=52; i++) {
            deck.add(i);
        }
        //sets up the container
        cardPane.setAlignment(Pos.CENTER);
        cardPane.setPadding(new Insets(20));

        //shows the 4 cards
        getCards();

        //creates and formats the New Cards button
        Button btnNewCards = new Button("New Cards");
        HBox buttonPane = new HBox(btnNewCards);
        buttonPane.setAlignment(Pos.CENTER);
        buttonPane.setPadding(new Insets(0, 0, 20, 0));
        btnNewCards.setOnAction(e -> getCards());

        //configures pane arrangement
        BorderPane mainPane = new BorderPane();
        mainPane.setCenter(cardPane);
        mainPane.setBottom(buttonPane);

        //set up stage
        Scene scene = new Scene(mainPane, 600, 300);
        primaryStage.setTitle("Four Random Cards");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    //removes old cards and displays new, random, cards
    private void getCards() {
        Collections.shuffle(deck);
        cardPane.getChildren().clear();

        for (int i = 0; i < 4; i++) {
            int cardNumber = deck.get(i);

            //links to card images
            String cardPath = "cards/" + cardNumber + ".png";

            try {
                //
                javafx.scene.image.Image cardImage = new javafx.scene.image.Image(getClass().getResourceAsStream(cardPath));
                //
                javafx.scene.image.ImageView cardView = new javafx.scene.image.ImageView(cardImage);

                cardView.setFitHeight(200);
                cardView.setPreserveRatio(true);

                cardPane.getChildren().add(cardView);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public static void main(String[] args) {
        launch(args);
    }
}